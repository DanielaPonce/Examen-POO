﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Examen_POO.util
{
    public class Expressions
    {
        public Regex CODIGO_PRODUCTO = new Regex("^\\d{6}");
        public Regex NOMBRE = new Regex("[a-zA-Z ]{2,254}");
        public Regex PRECIO = new Regex("\\A([0-9])+((,)?[0-9]*)((.)?[0-9]+)\\Z");
    }
}

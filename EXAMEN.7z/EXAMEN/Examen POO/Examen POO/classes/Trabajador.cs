﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Examen_POO.classes
{
    public class Trabajador
    {
        public int Codigo { get; set; }
        public string Nombres { get; set; }
        public string Turno { get; set; }

        public double GetSueldo()
        {
            double sueldo = 0;

            switch (Turno)
            {
                case "mañana":
                    sueldo = 1500;
                    break;
                case "tarde":
                    sueldo = 1700;
                    break;
                case "noche":
                    sueldo = 1900;
                    break;
            }

            return sueldo;
        }
    }
}

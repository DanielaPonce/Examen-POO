﻿namespace Examen_POO
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.btnPregunta1 = new System.Windows.Forms.Button();
            this.btnPregunta2 = new System.Windows.Forms.Button();
            this.btnPregunta3 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(59, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(110, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Preguntas";
            // 
            // btnPregunta1
            // 
            this.btnPregunta1.AutoSize = true;
            this.btnPregunta1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPregunta1.Location = new System.Drawing.Point(58, 62);
            this.btnPregunta1.Name = "btnPregunta1";
            this.btnPregunta1.Size = new System.Drawing.Size(111, 34);
            this.btnPregunta1.TabIndex = 1;
            this.btnPregunta1.Text = "Pregunta 1";
            this.btnPregunta1.UseVisualStyleBackColor = true;
            this.btnPregunta1.Click += new System.EventHandler(this.BtnPregunta1_Click);
            // 
            // btnPregunta2
            // 
            this.btnPregunta2.AutoSize = true;
            this.btnPregunta2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPregunta2.Location = new System.Drawing.Point(58, 112);
            this.btnPregunta2.Name = "btnPregunta2";
            this.btnPregunta2.Size = new System.Drawing.Size(111, 34);
            this.btnPregunta2.TabIndex = 2;
            this.btnPregunta2.Text = "Pregunta 2";
            this.btnPregunta2.UseVisualStyleBackColor = true;
            this.btnPregunta2.Click += new System.EventHandler(this.BtnPregunta2_Click);
            // 
            // btnPregunta3
            // 
            this.btnPregunta3.AutoSize = true;
            this.btnPregunta3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPregunta3.Location = new System.Drawing.Point(58, 167);
            this.btnPregunta3.Name = "btnPregunta3";
            this.btnPregunta3.Size = new System.Drawing.Size(111, 34);
            this.btnPregunta3.TabIndex = 3;
            this.btnPregunta3.Text = "Pregunta 3";
            this.btnPregunta3.UseVisualStyleBackColor = true;
            this.btnPregunta3.Click += new System.EventHandler(this.BtnPregunta3_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(222, 240);
            this.Controls.Add(this.btnPregunta3);
            this.Controls.Add(this.btnPregunta2);
            this.Controls.Add(this.btnPregunta1);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Preguntas";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnPregunta1;
        private System.Windows.Forms.Button btnPregunta2;
        private System.Windows.Forms.Button btnPregunta3;
    }
}


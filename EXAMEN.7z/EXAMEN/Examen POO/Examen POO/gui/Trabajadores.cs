﻿using Examen_POO.classes;
using Examen_POO.util;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Examen_POO.gui
{
    public partial class Trabajadores : Form
    {
        public Trabajadores()
        {
            InitializeComponent();
            GenerarCodigo();
        }

        List<Trabajador> trabajadores = new List<Trabajador>();
        Expressions expressions = new Expressions();

        private void BtnAgregar_Click(object sender, EventArgs e)
        {
            if (Validations())
            {
                Trabajador trabajadorCodigo = trabajadores.Find(worker => worker.Codigo == Convert.ToInt32(txtCodigo.Text));

                if (trabajadorCodigo != null)
                {
                    MessageBox.Show("El código ya fue registrado anteriormente", "Añadir", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                Trabajador trabajador = new Trabajador
                {
                    Codigo = Convert.ToInt32(txtCodigo.Text),
                    Nombres = txtNombres.Text,
                    Turno = cboTurno.SelectedItem.ToString().ToLower()
                };


                trabajadores.Add(trabajador);

                Listar();
                ClearInputs();
                GenerarCodigo();
            }
        }

        private void BtnReporte_Click(object sender, EventArgs e)
        {
            string content = GetWorkers();

            if (string.IsNullOrEmpty(content))
            {
                MessageBox.Show("No existen datos para exportar", "Exportar TXT", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                SaveFileDialog saveFileDialog = new SaveFileDialog
                {
                    Filter = "Archivo de texto (*.txt)|*.txt",
                    Title = "Exportar Trabajadores"
                };

                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    if (!string.IsNullOrEmpty(saveFileDialog.FileName))
                    {
                        StreamWriter streamWriter = new StreamWriter(saveFileDialog.FileName);
                        streamWriter.Write(content);
                        streamWriter.Close();

                        MessageBox.Show("Se generó el archivo", "Exportar", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
        }

        bool Validations()
        {
            if (string.IsNullOrEmpty(txtNombres.Text))
            {
                MessageBox.Show("El nombre no puede estar vacío", "Añadir", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                txtNombres.Focus();
                return false;
            }
            else if (!expressions.NOMBRE.IsMatch(txtNombres.Text))
            {
                MessageBox.Show("El nombre debe ser sólo letras", "Añadir", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                txtNombres.Focus();
                return false;
            }

            return true;
        }

        string GetWorkers()
        {
            StringBuilder stringBuilder = new StringBuilder();

            foreach (Trabajador trabajador in trabajadores)
            {
                stringBuilder.AppendLine($"{trabajador.Codigo}; {trabajador.Nombres}; {trabajador.Turno}; {trabajador.GetSueldo()}");
            }

            return stringBuilder.ToString();
        }

        void GenerarCodigo()
        {
            int sizeTrabajadores = trabajadores.Count();
            int codigo = sizeTrabajadores;

            codigo++;

            txtCodigo.Text = codigo.ToString();
        }

        void Listar()
        {
            lvTrabajadores.Items.Clear();
            foreach (Trabajador trabajador in trabajadores)
            {
                ListViewItem item = new ListViewItem(trabajador.Codigo.ToString());
                item.SubItems.Add(trabajador.Nombres);
                item.SubItems.Add(trabajador.Turno);
                item.SubItems.Add($"${trabajador.GetSueldo().ToString()}");

                lvTrabajadores.Items.Add(item);
            }
        }

        void ClearInputs()
        {
            txtCodigo.Clear();
            txtNombres.Clear();
            txtNombres.Focus();
        }
    }
}

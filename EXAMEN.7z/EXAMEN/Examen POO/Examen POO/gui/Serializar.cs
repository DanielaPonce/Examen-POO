﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;
using Examen_POO.classes;
using Examen_POO.util;

namespace Examen_POO.gui
{
    public partial class Serializar : Form
    {
        public Serializar()
        {
            InitializeComponent();
        }
        Productos productos = new Productos();
        Expressions expressions = new Expressions();

        private void BtnAgregar_Click(object sender, EventArgs e)
        {
            if (Validations())
            {
                Producto productCode = productos.list.Find(prod => prod.Codigo == Convert.ToInt32(txtCodigo.Text));

                if (productCode != null)
                {
                    MessageBox.Show("El codigo ya está registrado", "Añadir", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txtCodigo.Focus();
                }
                else
                {
                    Producto product = new Producto
                    {
                        Codigo = Convert.ToInt32(txtCodigo.Text),
                        Nombre = txtNombre.Text,
                        Marca = cboMarca.SelectedItem.ToString(),
                        FechaRegistro = DateTime.Now,
                        Precio = Convert.ToDouble(txtPrecio.Text)
                    };

                    productos.list.Add(product);

                    List();
                    ClearInputs();
                }
            }
        }



        private void BtnGuardar_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog
            {
                Filter = "Archivo XML (*.xml)|*.xml",
                Title = "Generar XML"
            };

            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                if (!string.IsNullOrEmpty(saveFileDialog.FileName))
                {
                    FileStream fileStream = new FileStream(saveFileDialog.FileName, FileMode.Create);
                    XmlSerializer xmlSerializer = new XmlSerializer(typeof(Productos));
                    xmlSerializer.Serialize(fileStream, productos);
                    fileStream.Close();

                    MessageBox.Show("El archivo se generó correctamente", "Generar XML", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void BtnAbrir_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Filter = "Archivo XML (*.xml)|*.xml",
                Title = "Cargar XML"
            };

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                if (!string.IsNullOrEmpty(openFileDialog.FileName))
                {
                    FileStream fileStream = new FileStream(openFileDialog.FileName, FileMode.Open);
                    XmlSerializer xml = new XmlSerializer(typeof(Productos));
                    productos = (Productos)xml.Deserialize(fileStream);
                    List();
                    ClearInputs();
                }
            }
        }

        bool Validations()
        {
            if (string.IsNullOrEmpty(txtCodigo.Text))
            {
                MessageBox.Show("El codigo no puede estar vacío", "Añadir", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                txtCodigo.Focus();
                return false;
            }
            else if (!expressions.CODIGO_PRODUCTO.IsMatch(txtCodigo.Text))
            {
                MessageBox.Show("El código debe ser de 6 dígitos numéricos", "Añadir", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                txtCodigo.Focus();
                return false;
            }
            else if (string.IsNullOrEmpty(txtNombre.Text))
            {
                MessageBox.Show("El nombre no puede estar vacío", "Añadir", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                txtNombre.Focus();
                return false;
            }
            else if (!expressions.NOMBRE.IsMatch(txtNombre.Text))
            {
                MessageBox.Show("El nombre debe ser sólo letras", "Añadir", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                txtNombre.Focus();
                return false;
            }
            else if (string.IsNullOrEmpty(txtPrecio.Text))
            {
                MessageBox.Show("El precio no puede estar vacío", "Añadir", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                txtPrecio.Focus();
                return false;
            }
            else if (!expressions.PRECIO.IsMatch(txtPrecio.Text))
            {
                MessageBox.Show("El precio sólo debe ser un número", "Añadir", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                txtPrecio.Focus();
                return false;
            }
            else if (Convert.ToDouble(txtPrecio.Text) <= 0)
            {
                MessageBox.Show("El precio no puede ser menor o igual a 0", "Añadir", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                txtPrecio.Focus();
                return false;
            }

            return true;
        }

        void List()
        {
            lvProductos.Items.Clear();
            foreach (Producto product in productos.list)
            {
                ListViewItem item = new ListViewItem(product.Codigo.ToString());
                item.SubItems.Add(product.Nombre);
                item.SubItems.Add(product.Marca);
                item.SubItems.Add(product.FechaRegistro.ToString());
                item.SubItems.Add($"${product.Precio.ToString()}");

                lvProductos.Items.Add(item);
            }
        }

        void ClearInputs()
        {
            txtCodigo.Clear();
            txtNombre.Clear();
            txtPrecio.Clear();
            txtCodigo.Focus();
        }
    }
}

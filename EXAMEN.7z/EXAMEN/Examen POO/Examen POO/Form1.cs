﻿using Examen_POO.gui;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Examen_POO
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnPregunta1_Click(object sender, EventArgs e)
        {
            Trabajadores trabajadores = new Trabajadores();
            trabajadores.Show();
        }

        private void BtnPregunta2_Click(object sender, EventArgs e)
        {
            Serializar serializar = new Serializar();
            serializar.Show();
        }

        private void BtnPregunta3_Click(object sender, EventArgs e)
        {
            Pregunta3 pregunta3 = new Pregunta3();
            pregunta3.Show();
        }
    }
}
